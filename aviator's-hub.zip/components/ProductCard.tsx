import React from 'react';
import type { Product } from '../types';

interface ProductCardProps {
  product: Product;
}

const ArrowRightIcon: React.FC<{ className?: string }> = ({ className }) => (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className={className} aria-hidden="true">
        <path strokeLinecap="round" strokeLinejoin="round" d="M13.5 4.5 21 12m0 0-7.5 7.5M21 12H3" />
    </svg>
);

const ExternalLinkIcon: React.FC<{ className?: string }> = ({ className }) => (
  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className={className} aria-hidden="true">
    <path strokeLinecap="round" strokeLinejoin="round" d="M13.5 6H5.25A2.25 2.25 0 0 0 3 8.25v10.5A2.25 2.25 0 0 0 5.25 21h10.5A2.25 2.25 0 0 0 18 18.75V10.5m-10.5 6L21 3m0 0h-5.25M21 3v5.25" />
  </svg>
);

const ProductCard: React.FC<ProductCardProps> = ({ product }) => {
  return (
    <a
      href={product.gumroadUrl}
      target="_blank"
      rel="noopener noreferrer"
      aria-label={`${product.name} - ${product.cta} (opens in new tab)`}
      className="group block h-full p-8 bg-slate-800/50 rounded-lg border border-slate-700 hover:border-sky-500 transition-all duration-300 ease-in-out transform hover:-translate-y-1 hover:shadow-2xl hover:shadow-sky-900/50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-slate-900 focus:ring-sky-500"
    >
      <div className="flex flex-col h-full">
        <div className="flex justify-between items-start">
          <h2 className="text-2xl font-bold text-slate-100 group-hover:text-sky-400 transition-colors duration-300 pr-2">
            {product.name}
          </h2>
          <ExternalLinkIcon className="w-5 h-5 text-slate-500 group-hover:text-sky-400 transition-colors duration-300 flex-shrink-0 mt-1" />
        </div>
        <p className="mt-2 text-slate-400 flex-grow">
          {product.description}
        </p>
        <div className="mt-6 flex items-center text-sky-400 font-semibold">
          <span>{product.cta}</span>
          <ArrowRightIcon className="w-5 h-5 ml-2 transform transition-transform duration-300 group-hover:translate-x-1" />
        </div>
      </div>
    </a>
  );
};

export default ProductCard;