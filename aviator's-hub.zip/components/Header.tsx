import React from 'react';

const PlaneIcon: React.FC<{ className?: string }> = ({ className }) => (
  <svg
    xmlns="http://www.w3.org/2000/svg"
    viewBox="0 0 24 24"
    fill="currentColor"
    className={className}
    aria-hidden="true"
  >
    <path d="M20.34 9.32l-14-7a1 1 0 00-1.11.21l-2 2a1 1 0 00-.1.84l1.32 6.69a1 1 0 00.94.84l6.69 1.32a1 1 0 00.84-.1l2-2a1 1 0 00.21-1.11l-7-14 .38.19 6.22 3.11L18 8.44l3.5 3.5 1.41-1.41-3.41-3.41L21.56 5 20 3.44l-2.06 2.06-3.11-6.22.19.38-7 14 1.11-.21 2-2 .1-.84-1.32-6.69-.94-.84-6.69-1.32.84.1 2 2 .21 1.11 14 7-3.11-6.22-2.06 2.06L18 3.44 19.56 5l-2.06 2.06 3.41 3.41-1.41 1.41-3.5-3.5-2.56-1.28z" transform="rotate(45 12 12)" />
  </svg>
);

const Header: React.FC = () => {
  return (
    <header className="bg-slate-900/70 backdrop-blur-md sticky top-0 z-50 border-b border-slate-800">
      <div className="container mx-auto px-6 py-4">
        <div className="flex items-center justify-center">
          <PlaneIcon className="w-8 h-8 text-sky-400 mr-3" />
          <span className="text-2xl font-bold tracking-tight text-white">
            Aviator's Hub
          </span>
        </div>
      </div>
    </header>
  );
};

export default Header;
